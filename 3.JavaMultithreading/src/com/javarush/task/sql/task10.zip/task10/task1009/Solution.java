package com.javarush.task.sql.task10.task1009;

import org.hibernate.Session;
import org.hibernate.query.Query;

/* 
task1009
*/

public class Solution {

    public static void main(String[] args) throws Exception {
        System.out.println("Salary fund: $" + getSalaryFund());
        System.out.println("Agerage age: " + getAverageAge());
    }

    public static Long getSalaryFund() {
        //напишите тут ваш код
        return 0L;
    }

    public static Double getAverageAge() {
        //напишите тут ваш код
        return 0.0;
    }
}