package com.javarush.task.sql.task13.task1303;

import org.hibernate.Session;
import org.hibernate.query.Query;
import com.javarush.task.sql.task13.task1303.entities.Publisher;

import java.util.List;

/* 
Опять книги
*/

public class Solution {

    public static void main(String[] args) throws Exception {
        List<Publisher> publishers;

        //напишите тут ваш код

//        publishers.stream().map(Publisher::getName).forEach(System.out::println);
    }
}
