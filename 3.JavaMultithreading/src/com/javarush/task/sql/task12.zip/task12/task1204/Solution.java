package com.javarush.task.sql.task12.task1204;

/* 
Время создания и изменения данных
*/

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Properties;

//напишите тут ваш код
public class Solution {
        //напишите тут ваш код

}
