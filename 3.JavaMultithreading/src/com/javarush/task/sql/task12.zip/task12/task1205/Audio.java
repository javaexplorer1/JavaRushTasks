package com.javarush.task.sql.task12.task1205;

/* 
Сохранить аудио файл в БД
*/

//import com.vladmihalcea.hibernate.type.json.JsonType;
import jakarta.persistence.*;
import org.hibernate.annotations.Type;
//import org.hibernate.annotations.TypeDef;
import java.util.Map;

//напишите тут ваш код
public class Audio {
    //напишите тут ваш код

}
