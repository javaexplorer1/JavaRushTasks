package com.javarush.task.sql.task12.task1201;

/*
Создаём Entity из класса
*/

//напишите тут ваш код
public class Library {
    //напишите тут ваш код

}
