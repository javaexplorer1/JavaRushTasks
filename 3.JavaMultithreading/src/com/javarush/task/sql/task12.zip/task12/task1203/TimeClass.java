package com.javarush.task.sql.task12.task1203;

/* 
Сохраняем объект в БД
*/

import jakarta.persistence.*;
import java.time.Instant;
import java.time.ZonedDateTime;

//напишите тут ваш код
public class TimeClass {
    //напишите тут ваш код

}