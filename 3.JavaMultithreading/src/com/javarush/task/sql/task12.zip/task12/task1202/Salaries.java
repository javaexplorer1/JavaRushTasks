package com.javarush.task.sql.task12.task1202;

/* 
Entity с вычислением
*/

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.Type;

//напишите тут ваш код
public class Salaries {
    //напишите тут ваш код

}
